// 신규 개업(인허가) 데이터 — 행정안전부 지방행정 인허가 API (공공데이터포털)
// 인증키: Netlify 환경변수 DATA_GO_KR_KEY (코드·사이트에 키를 두지 않음)
// 업종(서비스)별로 따로 저장 → 한 번에 다 못 받아도(느린 업종·시간 초과) 다음 실행에서 이어서 받음
import proj4 from "proj4";
import { getStore } from "@netlify/blobs";
import REGIONS from "./regions.mjs";

export const DAYS = 90;
const BASE = "https://apis.data.go.kr/1741000/";
const TM5174 = "+proj=tmerc +lat_0=38 +lon_0=127.0028902777778 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +no_defs +towgs84=-115.80,474.99,674.11,1.16,-2.31,-1.63,6.43";
const BUDGET_MS = 21000; // 함수 시간 제한 안에서 끝내기 위한 작업 시간

// 서비스 → 업종 카드 (활용신청 안 된 서비스는 자동으로 건너뜀 → 나중에 신청하면 그대로 반영)
const BAR = /호프|통닭|주점|소주방|대포집|룸살롱|라이브카페|간이주점/;
const SERVICES = {
  general_restaurants: b => (BAR.test(b) ? "bar" : /까페|카페/.test(b) ? "cafe" : "food"),
  rest_cafes: b => (/편의점/.test(b) ? "retail" : /패스트푸드|김밥|분식/.test(b) ? "food" : "cafe"),
  bakeries: () => "cafe",
  singing_bars: () => "bar",
  entertainment_bars: () => "bar",
  instant_food_processors: () => "retail",
  livestock_retail: () => "retail",
  tobacco_retailers: () => "retail",
  health_functional_food_general_retailers: () => "retail",
  optical_shops: () => "retail",
  beauty_salons: () => "beauty",
  barber_shops: () => "beauty",
  laundries: () => "laundry",
  fitness_centers: () => "fitness",
  golf_practice_ranges: () => "fitness",
  billiard_halls: () => "fitness",
  swimming_pools: () => "fitness",
  dance_academies: () => "fitness",
  martial_arts_dojo: () => "martial",
  karaoke_rooms: () => "pc",
  pc_bangs: () => "pc",
  general_game_providers: () => "pc",
  youth_game_providers: () => "pc",
  mixed_game_providers: () => "pc",
  lodgings: () => "lodging",
  pharmacies: () => "pharmacy",
  clinics: () => "clinic",
  hospitals: () => "clinic",
  animal_hospitals: () => "pet",
  pet_grooming: () => "pet",
  animal_sales: () => "pet",
};

const CITIES = [...new Set(REGIONS.map(([, n]) => n.split(" ")[0]))]; // 수원시, 오산시, 화성시 ...
let _store = null;
const store = () => _store || getStore("newopen");
export const __setStore = s => { _store = s; }; // 로컬 테스트용
const ymd = d => d.toISOString().slice(0, 10).replace(/-/g, "");
const dash = s => s.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3");

function regionOf(addr) {
  const a = (addr || "").replace(/^경기도\s*/, "");
  let best = null;
  for (const [code, name] of REGIONS) if (a.startsWith(name) && (!best || name.length > best[1].length)) best = [code, name];
  return best ? best[0] : null;
}

async function getJSON(url, tries = 2, ms = 15000) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(ms) });
      const t = await r.text();
      if (t.startsWith("{") && t.includes('"response"')) return JSON.parse(t);
      if (/SERVICE_KEY_IS_NOT_REGISTERED|SERVICE ACCESS DENIED|NOT_REGISTERED/i.test(t)) return { notApproved: true };
    } catch (e) { /* retry */ }
  }
  return { failed: true };
}

async function pool(tasks, n) {
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: n }, async () => { while (i < tasks.length) { const k = i++; out[k] = await tasks[k](); } }));
  return out;
}

function toItem(svc, x) {
  const addr = x.ROAD_NM_ADDR || x.LOTNO_ADDR || "";
  const code = regionOf(addr) || regionOf(x.LOTNO_ADDR);
  const X = parseFloat(x.CRD_INFO_X), Y = parseFloat(x.CRD_INFO_Y);
  if (!code || !X || !Y) return null;
  const [lng, lat] = proj4(TM5174, "WGS84", [X, Y]);
  const biz = x.BZSTAT_SE_NM || x.SNTTN_BZSTAT_NM || "";
  const area = parseFloat(x.LCTN_AREA) || 0;
  return {
    id: x.MNG_NO, code, svc, cid: SERVICES[svc](biz), name: (x.BPLC_NM || "").trim(), kind: biz,
    open: dash((x.LCPMT_YMD || "").replace(/-/g, "")), addr: addr.replace(/^경기도\s*/, ""),
    area: area ? Math.round(area) : 0, multi: x.MLT_UTZTN_BSNSSP_YN === "Y" ? 1 : 0,
    lat: +lat.toFixed(5), lng: +lng.toFixed(5),
  };
}

export async function refresh() {
  const key = process.env.DATA_GO_KR_KEY;
  if (!key) throw new Error("DATA_GO_KR_KEY 환경변수가 없습니다");
  const t0 = Date.now();
  const since = ymd(new Date(Date.now() - DAYS * 864e5));
  const qs = (page, city) => new URLSearchParams({ serviceKey: key, pageNo: String(page), numOfRows: "100", returnType: "json",
    "cond[LCPMT_YMD::GTE]": since, "cond[SALS_STTS_CD::EQ]": "01", "cond[ROAD_NM_ADDR::LIKE]": "경기도 " + city })
    .toString().replace(/%5B/g, "[").replace(/%5D/g, "]").replace(/%3A/g, ":");
  const st = store();
  const meta = (await st.get("svcmeta", { type: "json" }).catch(() => null)) || {};

  // 오래된 업종부터 (실패·미수집 우선)
  const order = Object.keys(SERVICES).sort((a, b) => (meta[a]?.built || "").localeCompare(meta[b]?.built || ""));

  const runSvc = async svc => {
    if (Date.now() - t0 > BUDGET_MS) return;
    const prev = (await st.get("svc/" + svc, { type: "json" }).catch(() => null)) || { items: [] };
    const rows = []; const failedCities = [];
    let notApproved = false;
    await pool(CITIES.map(city => async () => {
      if (notApproved) return;
      if (Date.now() - t0 > BUDGET_MS) { failedCities.push(city); return; }
      for (let page = 1; page <= 30; page++) {
        const j = await getJSON(BASE + svc + "/info?" + qs(page, city), 2, 15000);
        if (j.notApproved) { notApproved = true; return; }
        if (j.failed) { failedCities.push(city); return; }
        const body = j.response?.body || {};
        let it = body.items?.item || [];
        if (!Array.isArray(it)) it = [it];
        rows.push(...it);
        if (page * 100 >= (body.totalCount || 0)) break;
        if (Date.now() - t0 > BUDGET_MS) { failedCities.push(city); return; }
      }
    }), 3);
    if (notApproved) { meta[svc] = { built: new Date().toISOString(), status: "활용신청 필요", count: 0 }; await st.setJSON("svc/" + svc, { items: [] }); return; }
    const sinceDash = dash(since);
    const items = rows.map(x => toItem(svc, x)).filter(Boolean);
    // 이번에 못 받은 시는 이전 데이터 유지
    for (const it of prev.items || []) if (failedCities.includes((it.addr || "").split(" ")[0]) && it.open >= sinceDash) items.push(it);
    const ok = failedCities.length === 0;
    await st.setJSON("svc/" + svc, { items });
    meta[svc] = { built: ok ? new Date().toISOString() : (meta[svc]?.built || ""), status: ok ? "ok" : `일부 미수집(${failedCities.length}개 시)`, count: items.length };
  };
  await pool(order.map(svc => () => runSvc(svc)), 4);
  await st.setJSON("svcmeta", meta);
  return rebuild(meta);
}

// 업종별 저장분을 합쳐 화면용 데이터 만들기
export async function rebuild(meta) {
  const st = store();
  meta = meta || (await st.get("svcmeta", { type: "json" }).catch(() => null)) || {};
  const sinceDash = dash(ymd(new Date(Date.now() - DAYS * 864e5)));
  const all = [];
  for (const svc of Object.keys(SERVICES)) {
    const b = await st.get("svc/" + svc, { type: "json" }).catch(() => null);
    if (b?.items) all.push(...b.items.filter(i => i.open >= sinceDash));
  }
  // 같은 가게가 여러 인허가(예: 편의점 = 휴게음식점 + 담배소매)로 잡히면 하나만
  const seen = new Set(); const items = [];
  all.sort((a, b) => b.open.localeCompare(a.open));
  for (const it of all) {
    const k = it.name.replace(/\s|\(.*?\)/g, "") + "|" + it.lat.toFixed(4) + "," + it.lng.toFixed(4);
    if (seen.has(k)) continue; seen.add(k); items.push(it);
  }
  const status = Object.fromEntries(Object.entries(meta).map(([k, v]) => [k, v.status]));
  const data = { built: new Date().toISOString(), days: DAYS, since: sinceDash, status, count: items.length, items };
  await st.setJSON("latest", data);
  return data;
}

export async function latest() {
  return store().get("latest", { type: "json" });
}

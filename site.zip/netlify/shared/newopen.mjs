// 신규 개업(인허가) 데이터 — 행정안전부 지방행정 인허가 API (공공데이터포털)
// 인증키: Netlify 환경변수 DATA_GO_KR_KEY (코드·사이트에 키를 두지 않음)
import proj4 from "proj4";
import { getStore } from "@netlify/blobs";
import REGIONS from "./regions.mjs";

export const DAYS = 90;
const BASE = "https://apis.data.go.kr/1741000/";
const TM5174 = "+proj=tmerc +lat_0=38 +lon_0=127.0028902777778 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m +no_defs +towgs84=-115.80,474.99,674.11,1.16,-2.31,-1.63,6.43";

// 서비스 → 업종 카드 (활용신청 안 된 서비스는 자동으로 건너뜀 → 나중에 신청하면 그대로 반영)
const BAR = /호프|통닭|주점|소주방|대포집|룸살롱|라이브카페|간이주점/;
const SERVICES = {
  general_restaurants: b => (BAR.test(b) ? "bar" : /까페|카페/.test(b) ? "cafe" : "food"),
  rest_cafes: b => (/편의점/.test(b) ? "retail" : /패스트푸드|김밥|분식/.test(b) ? "food" : "cafe"),
  bakeries: () => "cafe",
  beauty_salons: () => "beauty",
  barber_shops: () => "beauty",
  laundries: () => "laundry",
  fitness_centers: () => "fitness",
  golf_practice_ranges: () => "fitness",
  billiard_halls: () => "fitness",
  swimming_pools: () => "fitness",
  karaoke_rooms: () => "pc",
  pc_bangs: () => "pc",
  lodgings: () => "lodging",
  pharmacies: () => "pharmacy",
  clinics: () => "clinic",
  hospitals: () => "clinic",
  animal_hospitals: () => "pet",
  pet_grooming: () => "pet",
  martial_arts_dojo: () => "martial",
  optical_shops: () => "retail",
};

const CITIES = [...new Set(REGIONS.map(([, n]) => n.split(" ")[0]))]; // 수원시, 오산시, 화성시 ...

function ymd(d) { return d.toISOString().slice(0, 10).replace(/-/g, ""); }

function regionOf(addr) {
  const a = addr.replace(/^경기도\s*/, "");
  let best = null;
  for (const [code, name] of REGIONS) if (a.startsWith(name) && (!best || name.length > best[1].length)) best = [code, name];
  return best ? best[0] : null;
}

async function getJSON(url, tries = 2) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      const t = await r.text();
      if (t.startsWith("{") && t.includes('"response"')) return JSON.parse(t);
      if (/SERVICE_KEY_IS_NOT_REGISTERED|SERVICE ACCESS DENIED|NOT_REGISTERED/i.test(t)) return { notApproved: true };
    } catch (e) { /* retry */ }
  }
  return { failed: true };
}

async function pool(tasks, n) {
  const out = []; let i = 0;
  await Promise.all(Array.from({ length: n }, async () => { while (i < tasks.length) { const k = i++; out[k] = await tasks[k](); } }));
  return out;
}

export async function refresh({ save = true } = {}) {
  const key = process.env.DATA_GO_KR_KEY;
  if (!key) throw new Error("DATA_GO_KR_KEY 환경변수가 없습니다");
  const since = ymd(new Date(Date.now() - DAYS * 864e5));
  const status = {};
  const items = [];

  const fetchAll = async (svc, city) => {
    const rows = [];
    for (let page = 1; page <= 20; page++) {
      const q = new URLSearchParams({ serviceKey: key, pageNo: String(page), numOfRows: "100", returnType: "json",
        "cond[LCPMT_YMD::GTE]": since, "cond[SALS_STTS_CD::EQ]": "01", "cond[ROAD_NM_ADDR::LIKE]": "경기도 " + city });
      const j = await getJSON(BASE + svc + "/info?" + q.toString().replace(/%5B/g, "[").replace(/%5D/g, "]").replace(/%3A/g, ":"));
      if (j.notApproved) { status[svc] = "활용신청 필요"; return rows; }
      if (j.failed) { status[svc] = "일시 오류"; return rows; }
      const body = j.response?.body || {};
      let it = body.items?.item || [];
      if (!Array.isArray(it)) it = [it];
      rows.push(...it);
      if (page * 100 >= (body.totalCount || 0)) break;
    }
    status[svc] = status[svc] || "ok";
    return rows;
  };

  // 1) 활용신청 된 서비스만 골라내기 (1건 조회)
  const probe = await pool(Object.keys(SERVICES).map(svc => async () => {
    const q = `serviceKey=${key}&pageNo=1&numOfRows=1&returnType=json`;
    const j = await getJSON(BASE + svc + "/info?" + q, 1);
    status[svc] = j.notApproved ? "활용신청 필요" : j.failed ? "일시 오류" : "ok";
    return status[svc] === "ok" ? svc : null;
  }), 10);
  // 2) 승인된 서비스 × 시 단위 조회
  const tasks = [];
  for (const svc of probe.filter(Boolean)) for (const city of CITIES) tasks.push(async () => [svc, await fetchAll(svc, city)]);
  const res = await pool(tasks, 12);

  const seen = new Set();
  for (const [svc, rows] of res) {
    for (const x of rows) {
      if (!x || seen.has(x.MNG_NO)) continue;
      seen.add(x.MNG_NO);
      const addr = x.ROAD_NM_ADDR || x.LOTNO_ADDR || "";
      const code = regionOf(addr) || regionOf(x.LOTNO_ADDR || "");
      const X = parseFloat(x.CRD_INFO_X), Y = parseFloat(x.CRD_INFO_Y);
      if (!code || !X || !Y) continue;
      const [lng, lat] = proj4(TM5174, "WGS84", [X, Y]);
      const biz = x.BZSTAT_SE_NM || x.SNTTN_BZSTAT_NM || "";
      const area = parseFloat(x.LCTN_AREA) || 0;
      items.push({
        code, cid: SERVICES[svc](biz), name: (x.BPLC_NM || "").trim(), kind: biz || "",
        open: (x.LCPMT_YMD || "").replace(/-/g, "").replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3"),
        addr: addr.replace(/^경기도\s*/, ""), area: area ? Math.round(area) : 0,
        multi: x.MLT_UTZTN_BSNSSP_YN === "Y" ? 1 : 0,
        lat: +lat.toFixed(5), lng: +lng.toFixed(5),
      });
    }
  }
  items.sort((a, b) => b.open.localeCompare(a.open));
  const data = { built: new Date().toISOString(), days: DAYS, since, status, count: items.length, items };
  if (save) await getStore("newopen").setJSON("latest", data);
  return data;
}

export async function latest() {
  const store = getStore("newopen");
  return store.get("latest", { type: "json" });
}

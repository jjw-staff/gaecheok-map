// 매일 새벽 5시(한국시간) 신규 개업 데이터 갱신 — 공공데이터는 2일 전 기준으로 매일 갱신됨
import { refresh } from "../shared/newopen.mjs";

export default async () => {
  const d = await refresh();
  console.log("newopen refreshed", d.count, JSON.stringify(d.status));
};

export const config = { schedule: "0 20 * * *" }; // UTC 20시 = KST 05시

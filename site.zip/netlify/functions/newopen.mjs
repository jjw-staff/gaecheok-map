// GET /api/newopen — 최근 90일 신규 개업 목록
// - 기본: 저장된 데이터를 바로 돌려줌. 하루 지났거나 덜 받은 업종이 있으면 needRefresh:true 표시
// - ?refresh=1 : 그 자리에서 이어받기 실행(최대 약 21초) 후 새 데이터 반환 (10분에 한 번까지)
//   → 사이트(app.js)가 needRefresh를 보면 화면과 상관없이 뒤에서 ?refresh=1 을 한 번 호출
import { latest, refresh } from "../shared/newopen.mjs";

export default async (req) => {
  let data = null;
  try { data = await latest(); } catch (e) { /* 저장소 비어 있음 */ }
  const age = data ? Date.now() - new Date(data.built).getTime() : Infinity;
  const incomplete = !data || !data.items?.[0]?.svc || Object.values(data.status || {}).some(s => s !== "ok" && s !== "활용신청 필요");
  const manual = new URL(req.url).searchParams.get("refresh") === "1";
  const need = age > 24 * 3600e3 || (incomplete && age > 10 * 60e3);
  if (!data || (manual && (need || age > 10 * 60e3))) {
    try { data = await refresh(); } catch (e) {
      if (!data) return Response.json({ error: "신규 개업 데이터를 아직 불러오지 못했어요", detail: String(e.message || e) }, { status: 503 });
    }
    return Response.json(data, { headers: { "Cache-Control": "no-store" } });
  }
  return Response.json({ ...data, needRefresh: need }, { headers: { "Cache-Control": "public, max-age=300" } });
};

export const config = { path: "/api/newopen" };

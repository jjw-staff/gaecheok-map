// GET /api/newopen — 최근 90일 신규 개업 목록 (매일 자동 갱신, 없거나 오래되면 즉시 갱신)
import { latest, refresh } from "../shared/newopen.mjs";

export default async () => {
  let data = null;
  try { data = await latest(); } catch (e) { /* 저장소 비어 있음 */ }
  const stale = !data || Date.now() - new Date(data.built).getTime() > 30 * 3600e3;
  if (stale) {
    try { data = await refresh(); } catch (e) {
      if (!data) return Response.json({ error: "신규 개업 데이터를 아직 불러오지 못했어요", detail: String(e.message || e) }, { status: 503 });
    }
  }
  return Response.json(data, { headers: { "Cache-Control": "public, max-age=1800" } });
};

export const config = { path: "/api/newopen" };

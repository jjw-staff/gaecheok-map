// GET /api/newopen — 최근 90일 신규 개업 목록
// 저장된 데이터를 바로 돌려주고, 30시간 넘게 지났으면 응답 후 뒤에서 갱신 (데이터가 아예 없을 때만 기다림)
import { latest, refresh } from "../shared/newopen.mjs";

export default async (req, context) => {
  let data = null;
  try { data = await latest(); } catch (e) { /* 저장소 비어 있음 */ }
  const age = data ? Date.now() - new Date(data.built).getTime() : Infinity;
  // ?refresh=1 : 수동 갱신 (1시간에 한 번까지만 — 공공데이터 일일 호출 한도 보호)
  const stale = age > 30 * 3600e3 || (new URL(req.url).searchParams.get("refresh") === "1" && age > 3600e3);
  if (!data) {
    try { data = await refresh(); } catch (e) {
      return Response.json({ error: "신규 개업 데이터를 아직 불러오지 못했어요", detail: String(e.message || e) }, { status: 503 });
    }
  } else if (stale) {
    context.waitUntil(refresh().catch(e => console.log("refresh failed", e)));
  }
  return Response.json(data, { headers: { "Cache-Control": "public, max-age=1800" } });
};

export const config = { path: "/api/newopen" };

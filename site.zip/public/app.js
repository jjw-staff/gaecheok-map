/* 개척 지도 — 경기지역단 */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const view = $("#view");
  const CARD = Object.fromEntries(CARDS.map(c => [c.id, c]));
  const store = {
    get(k, d) { try { const v = localStorage.getItem("gc_" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem("gc_" + k, JSON.stringify(v)); } catch (e) {} },
  };
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = n => n.toLocaleString("ko-KR");
  const today = () => new Date().toISOString().slice(0, 10);
  const daysSince = d => Math.floor((Date.now() - new Date(d + "T00:00:00").getTime()) / 864e5);

  function dist(a, b) { // km
    const R = 6371, r = Math.PI / 180;
    const dLa = (b[0] - a[0]) * r, dLo = (b[1] - a[1]) * r;
    const h = Math.sin(dLa / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dLo / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  }
  const km = d => d < 1 ? Math.round(d * 1000) + "m" : d.toFixed(1) + "km";
  const naverTo = s => `https://map.naver.com/p/search/${encodeURIComponent((s.name + " " + (s.addr || "").split(/[ ,]/).slice(0, 2).join(" ")).trim())}`;
  const kakaoTo = s => `https://map.kakao.com/link/to/${encodeURIComponent(s.name.replace(/,/g, " "))},${s.lat},${s.lng}`;

  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 2000);
  }

  /* ── 데이터 */
  let META = null;
  const cache = {};
  async function meta() {
    if (!META) META = await fetch("data/index.json", { cache: "no-cache" }).then(r => r.json());
    return META;
  }
  const region = code => META.regions.find(r => r.code === code);

  /* 신규 개업 (인허가 API → /api/newopen, 매일 갱신) — 실패하면 조용히 없이 동작 */
  let NEW = undefined;
  async function newOpen() {
    if (NEW !== undefined) return NEW;
    try {
      const r = await fetch("/api/newopen");
      NEW = r.ok ? await r.json() : null;
      if (NEW) {
        NEW.by = {};
        NEW.items.forEach(n => { ((NEW.by[n.code] ||= {})[n.cid] ||= []).push(n); });
      }
    } catch (e) { NEW = null; }
    return NEW;
  }
  const newCount = (code, cid) => !NEW || !NEW.by[code] ? 0 : cid ? (NEW.by[code][cid] || []).length : Object.values(NEW.by[code]).reduce((a, b) => a + b.length, 0);
  const norm = t => String(t).replace(/\s|\(.*?\)|주식회사|㈜/g, "").toLowerCase();
  const dongOf = a => ((a || "").match(/\(([^,()]*?(?:동|가|읍|면|리))(?:,|\))/) || [])[1] || "";
  const openDays = s => s.open ? daysSince(s.open) : null;

  async function rows(code, cid) {
    const k = code + "/" + cid;
    if (!cache[k]) {
      const arr = await fetch(`data/${code}/${cid}.json`).then(r => r.json()).catch(() => []);
      const list = arr.map(a => ({ name: a[0], kind: a[1], dong: a[2], addr: a[3], fl: a[4], lat: a[5], lng: a[6], cid, code, key: `${code}|${a[0]}|${a[5]},${a[6]}` }));
      await newOpen();
      for (const n of (NEW && NEW.by[code] && NEW.by[code][cid]) || []) {
        const nn = norm(n.name);
        const hit = list.find(s => norm(s.name) === nn && dist([s.lat, s.lng], [n.lat, n.lng]) < 0.08);
        const extra = { open: n.open, area: n.area, multi: n.multi };
        if (hit) Object.assign(hit, extra);
        else list.push({ name: n.name, kind: n.kind, dong: dongOf(n.addr), addr: n.addr, fl: "", lat: n.lat, lng: n.lng, cid, code, key: `${code}|${n.name}|${n.lat},${n.lng}`, ...extra });
      }
      cache[k] = list;
    }
    return cache[k];
  }

  /* ── 방문 기록 (이 휴대폰에만 저장) */
  const visits = () => store.get("visits", {});
  function markVisit(s, memo) {
    const v = visits();
    const cur = v[s.key] || { name: s.name, cid: s.cid, code: s.code, addr: s.addr, kind: s.kind, lat: s.lat, lng: s.lng, dates: [] };
    if (cur.dates[cur.dates.length - 1] !== today()) cur.dates.push(today());
    if (memo != null) cur.memo = memo;
    v[s.key] = cur; store.set("visits", v);
  }
  function unVisit(key) { const v = visits(); delete v[key]; store.set("visits", v); }

  /* ── 헤더·탭 */
  function chrome(title, sub, back, tab) {
    $("#title").textContent = title; $("#subtitle").textContent = sub || "";
    const b = $("#back"); b.hidden = !back; b.onclick = () => (location.hash = back);
    document.querySelectorAll(".tabbar a").forEach(a => a.classList.toggle("on", a.dataset.tab === tab));
    closeSheet();
    window.scrollTo(0, 0);
  }

  /* ── 홈: 시·구 선택 */
  async function home() {
    await meta(); await newOpen();
    chrome("개척 지도", "경기지역단 · 공공데이터로 찾는 개척 대상", null, "map");
    const centers = [...new Set(META.regions.map(r => r.center))];
    let center = store.get("center", centers[0]);
    if (!centers.includes(center)) center = centers[0];
    const draw = () => {
      const regs = META.regions.filter(r => r.center === center);
      view.innerHTML = `
        ${META.sample ? `<div class="notice">지금은 <b>샘플 데이터</b>로 화면만 보여 드리고 있어요. 실제 상가 데이터는 곧 반영됩니다.</div>` : ""}
        <section class="hero">
          <p class="eyebrow">오늘 어디로 갈까요?</p>
          <h1>시·구를 고르면<br>업종별 개척 대상이 나와요</h1>
        </section>
        <div class="seg">${centers.map(c => `<button data-c="${c}" class="${c === center ? "on" : ""}">${c.replace("센터", "")}</button>`).join("")}</div>
        <div class="regions">
          ${regs.map(r => {
            const top = Object.entries(r.cards).slice(0, 3).map(([id]) => CARD[id].short).join(" · ");
            return `<a class="region" href="#/r/${r.code}">
              <div><b>${esc(r.name)}${newCount(r.code) ? ` <span class="newchip">신규 ${newCount(r.code)}</span>` : ""}</b><small>${top} 많음</small></div>
              <span class="num">${fmt(r.total)}<em>곳</em></span>
            </a>`;
          }).join("")}
        </div>
        <p class="foot">데이터: ${esc(META.source)} · ${esc(META.built)} 반영${NEW ? `<br>신규 개업: 행정안전부 인허가 데이터 · 최근 ${NEW.days}일 · 매일 갱신` : ""}<br>상호·업종·주소 등 공개된 사업장 정보만 사용합니다.</p>`;
      view.querySelectorAll(".seg button").forEach(b => b.onclick = () => { center = b.dataset.c; store.set("center", center); draw(); });
    };
    draw();
  }

  /* ── 시·구 요약: 업종별 사업장 수 */
  async function regionView(code) {
    await meta(); await newOpen();
    const r = region(code);
    if (!r) return (location.hash = "#/");
    store.set("lastRegion", code);
    chrome(r.name, `${r.center} · 개척 대상 ${fmt(r.total)}곳`, "#/", "map");
    const list = Object.entries(r.cards);
    const max = list[0][1];
    const v = visits();
    const done = cid => Object.values(v).filter(x => x.code === code && x.cid === cid).length;
    view.innerHTML = `
      ${newCount(code) ? `<div class="newbanner"><b>최근 ${NEW.days}일 새로 문 연 가게 ${fmt(newCount(code))}곳</b><span>개업 초기는 보험 세팅이 덜 된 경우가 많아 첫 방문 타이밍으로 좋아요. 업종에 들어가 <em>신규 개업만</em>을 눌러 보세요.</span></div>` : ""}
      <p class="lead">업종을 고르면 지도와 가까운 순 목록, 첫 방문 화법이 나와요.</p>
      <div class="kinds">
        ${list.map(([cid, n]) => {
          const c = CARD[cid], d = done(cid);
          return `<a class="kind" href="#/r/${code}/${cid}">
            <i style="background:${c.color}"></i>
            <div class="k-main"><b>${c.name}</b>
              <div class="bar"><span style="width:${Math.max(4, n / max * 100)}%;background:${c.color}"></span></div>
            </div>
            <div class="k-num"><b>${fmt(n)}</b>${newCount(code, cid) ? `<small class="nw">신규 ${newCount(code, cid)}</small>` : ""}${d ? `<small>방문 ${d}</small>` : ""}</div>
          </a>`;
        }).join("")}
      </div>`;
  }

  /* ── 업종 탐색: 지도 + 목록 */
  let map = null;
  async function explore(code, cid) {
    await meta();
    const r = region(code), c = CARD[cid];
    if (!r || !c) return (location.hash = "#/");
    chrome(c.name, r.name, `#/r/${code}`, "map");
    view.innerHTML = `<div class="loading">불러오는 중…</div>`;
    const all = await rows(code, cid);

    const nNew = all.filter(s => s.open).length;
    const st = { dong: "", hide: false, onlyNew: false, origin: store.get("origin_" + code, null), route: null, shown: 60 };
    view.innerHTML = `
      <div class="mapwrap"><div id="map"></div>
        <button class="fab" id="me" title="내 위치"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/><circle cx="12" cy="12" r="7.5"/></svg></button>
      </div>
      <a class="cardlink" href="#/card/${cid}" style="--c:${c.color}">
        <span><b>${c.name} 첫 방문 화법</b><small>필요한 보험 · 화법 · 거절 대응</small></span>
        <svg viewBox="0 0 24 24" width="20"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
      </a>
      <div class="filters">
        <select id="dong"><option value="">전체 동 (${fmt(all.length)})</option>
          ${r.dongs.filter(d => all.some(s => s.dong === d)).map(d => `<option>${esc(d)}</option>`).join("")}</select>
        <label class="chk"><input type="checkbox" id="hide"> 방문한 곳 숨기기</label>
      </div>
      ${nNew ? `<label class="newtoggle"><input type="checkbox" id="onlyNew"><span>신규 개업만 보기 <b>${nNew}곳</b> <small>최근 ${NEW.days}일</small></span></label>` : ""}
      <div class="routebar">
        <button class="btn primary" id="mkroute">가까운 10곳 동선 만들기</button>
        <button class="btn ghost" id="clrroute" hidden>동선 지우기</button>
      </div>
      <p class="origin" id="originTxt"></p>
      <div id="list" class="list"></div>`;

    if (map) { map.remove(); map = null; }
    map = L.map("map", { preferCanvas: true, zoomControl: false, attributionControl: true }).setView([r.lat, r.lng], 14);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" }).addTo(map);
    L.control.zoom({ position: "bottomleft" }).addTo(map);
    const layer = L.layerGroup().addTo(map);
    const routeLayer = L.layerGroup().addTo(map);
    let originMarker = null;

    const filtered = () => {
      const v = visits();
      return all.filter(s => (!st.dong || s.dong === st.dong) && (!st.hide || !v[s.key]) && (!st.onlyNew || s.open));
    };
    const originPt = () => st.origin || [r.lat, r.lng];

    function drawOrigin() {
      if (originMarker) originMarker.remove();
      if (st.origin) originMarker = L.marker(st.origin, { icon: L.divIcon({ className: "me-dot", iconSize: [18, 18] }) }).addTo(map);
      $("#originTxt").innerHTML = st.origin
        ? `<b>출발점</b> 기준 가까운 순 · <a href="#" id="resetO">해제</a>`
        : `◎ 버튼(내 위치)이나 <a href="#" id="centerO">지금 지도 가운데</a>를 <b>출발점</b>으로 정하면 가까운 순으로 정렬돼요`;
      const co = $("#centerO");
      if (co) co.onclick = e => { e.preventDefault(); const m = map.getCenter(); setOrigin([m.lat, m.lng], "지도 가운데를 출발점으로 정했어요"); };
      const ro = $("#resetO");
      if (ro) ro.onclick = e => { e.preventDefault(); st.origin = null; store.set("origin_" + code, null); render(); };
    }

    function render(fit) {
      const v = visits();
      const list = filtered();
      const o = originPt();
      list.forEach(s => (s.d = dist(o, [s.lat, s.lng])));
      if (st.origin) list.sort((a, b) => a.d - b.d);
      else if (st.onlyNew) list.sort((a, b) => b.open.localeCompare(a.open));
      layer.clearLayers();
      const draw = s => {
        const vis = !!v[s.key];
        L.circleMarker([s.lat, s.lng], s.open
          ? { radius: 9, weight: 3, color: "#191F28", fillColor: vis ? "#B9BBC6" : c.color, fillOpacity: 1 }
          : { radius: 7, weight: 2, color: "#fff", fillColor: vis ? "#B9BBC6" : c.color, fillOpacity: .95 })
          .on("click", () => openStore(s)).addTo(layer);
      };
      list.filter(s => !s.open).forEach(draw);
      list.filter(s => s.open).forEach(draw); // 신규 개업은 위에 그림
      if (fit && list.length) map.fitBounds(L.latLngBounds(list.map(s => [s.lat, s.lng])), { padding: [24, 24], maxZoom: 16 });
      drawOrigin();

      const items = st.route || list.slice(0, st.shown);
      $("#list").innerHTML = (st.route ? `<div class="route-sum">동선 ${st.route.length}곳 · 총 이동 약 <b>${km(st.route.total)}</b> (직선 기준)</div>` : "") +
        (items.length ? items.map((s, i) => `
          <div class="item ${v[s.key] ? "done" : ""}" data-k="${esc(s.key)}">
            ${st.route ? `<span class="no">${i + 1}</span>` : ""}
            <div class="it-main"><b>${s.open ? `<span class="nb">NEW</span>` : ""}${esc(s.name)}</b>
              <small>${s.open ? `<span class="nd">개업 ${openDays(s)}일째</span> · ` : ""}${esc(s.kind)}${s.dong ? " · " + esc(s.dong) : ""}${s.fl ? ` · ${esc(/^\d+$/.test(s.fl) ? s.fl + "층" : s.fl)}` : ""}</small>
              <small class="addr">${esc(s.addr)}</small></div>
            <div class="it-side">${st.origin || st.route ? `<em>${km(st.route ? s.leg : s.d)}</em>` : ""}${v[s.key] ? `<span class="badge">방문</span>` : ""}</div>
          </div>`).join("") : `<div class="empty">조건에 맞는 곳이 없어요</div>`) +
        (!st.route && list.length > st.shown ? `<button class="btn ghost more" id="more">더 보기 (${fmt(list.length - st.shown)}곳 남음)</button>` : "");
      $("#list").querySelectorAll(".item").forEach(el => el.onclick = () => openStore(all.find(s => s.key === el.dataset.k)));
      const m = $("#more"); if (m) m.onclick = () => { st.shown += 60; render(); };
      $("#clrroute").hidden = !st.route;
      $("#mkroute").textContent = st.route ? "동선 다시 만들기" : "가까운 10곳 동선 만들기";
    }

    function setOrigin(ll, msg) {
      st.origin = [+ll[0].toFixed(5), +ll[1].toFixed(5)]; store.set("origin_" + code, st.origin);
      st.route = null; routeLayer.clearLayers(); render(); if (msg) toast(msg);
    }

    $("#dong").onchange = e => { st.dong = e.target.value; st.shown = 60; st.route = null; routeLayer.clearLayers(); render(true); };
    $("#hide").onchange = e => { st.hide = e.target.checked; render(); };
    const on = $("#onlyNew");
    if (on) on.onchange = e => { st.onlyNew = e.target.checked; st.shown = 60; st.route = null; routeLayer.clearLayers(); render(true); };
    map.on("contextmenu", e => setOrigin([e.latlng.lat, e.latlng.lng], "여기를 출발점으로 정했어요"));
    $("#me").onclick = () => {
      if (!navigator.geolocation) return toast("위치 기능을 쓸 수 없어요");
      toast("내 위치 찾는 중…");
      navigator.geolocation.getCurrentPosition(p => {
        setOrigin([p.coords.latitude, p.coords.longitude], "내 위치를 출발점으로 정했어요");
        map.setView(st.origin, 15);
      }, () => toast("위치 권한을 허용해 주세요. 지도를 길게 눌러도 돼요"), { enableHighAccuracy: true, timeout: 8000 });
    };
    $("#mkroute").onclick = () => {
      const v = visits();
      let pool = filtered().filter(s => !v[s.key]);
      if (!pool.length) return toast("남은 곳이 없어요");
      let cur = originPt(); const route = []; route.total = 0;
      while (route.length < 10 && pool.length) {
        let bi = 0, bd = Infinity;
        pool.forEach((s, i) => { const d = dist(cur, [s.lat, s.lng]); if (d < bd) { bd = d; bi = i; } });
        const s = pool.splice(bi, 1)[0]; s.leg = bd; route.total += bd; route.push(s); cur = [s.lat, s.lng];
      }
      st.route = route;
      routeLayer.clearLayers();
      L.polyline([originPt(), ...route.map(s => [s.lat, s.lng])], { color: c.color, weight: 3, opacity: .8, dashArray: "6 6" }).addTo(routeLayer);
      route.forEach((s, i) => L.marker([s.lat, s.lng], { icon: L.divIcon({ className: "num-pin", html: `<span style="background:${c.color}">${i + 1}</span>`, iconSize: [26, 26] }) }).on("click", () => openStore(s)).addTo(routeLayer));
      map.fitBounds(L.latLngBounds([originPt(), ...route.map(s => [s.lat, s.lng])]), { padding: [30, 30] });
      render();
      if (!st.origin) toast("출발점이 없어 시·구 중심에서 시작했어요");
    };
    $("#clrroute").onclick = () => { st.route = null; routeLayer.clearLayers(); render(); };

    function openStore(s) {
      const v = visits()[s.key];
      const o = st.origin ? km(dist(st.origin, [s.lat, s.lng])) : "";
      showSheet(`
        <div class="sh-head"><i style="background:${c.color}"></i><div><b>${esc(s.name)}</b><small>${esc(s.kind)}${o ? " · 출발점에서 " + o : ""}</small></div></div>
        <p class="sh-addr">${esc(s.addr)}${s.fl ? ` · ${esc(/^\d+$/.test(s.fl) ? s.fl + "층" : s.fl)}` : ""}</p>
        ${s.open ? `<p class="sh-new"><b>신규 개업</b> ${esc(s.open)} 인허가 · 개업 ${openDays(s)}일째${s.area ? ` · 영업장 면적 약 ${fmt(s.area)}㎡` : ""}${s.multi ? " · 다중이용업소" : ""}<br><small>개업 초기라 화재·배상 세팅 점검 제안이 자연스러워요. "개업 축하드려요"로 시작해 보세요.</small></p>` : ""}
        ${v ? `<p class="sh-visit">방문 ${v.dates.length}회 · 마지막 ${v.dates[v.dates.length - 1]}${v.memo ? `<br>메모: ${esc(v.memo)}` : ""}</p>` : ""}
        <textarea id="memo" rows="2" maxlength="80" placeholder="가게 메모 (예: 사장님 3시 이후 계심) — 이 휴대폰에만 저장">${esc(v?.memo || "")}</textarea>
        <div class="sh-btns">
          <a class="btn naver" href="${naverTo(s)}" target="_blank" rel="noopener">네이버지도</a>
          <button class="btn primary" id="vis">${v ? "오늘 또 방문" : "방문했어요"}</button>
        </div>
        <div class="sh-sub">
          <span><a href="#/card/${cid}">${c.name} 화법 보기</a> · <a class="kk" href="${kakaoTo(s)}" target="_blank" rel="noopener">카카오맵</a></span>
          ${v ? `<button id="unv">방문 기록 지우기</button>` : ""}
        </div>`);
      $("#vis").onclick = () => { markVisit(s, $("#memo").value.trim()); closeSheet(); toast("방문 기록했어요 · 1주 안에 재방문!"); render(); };
      const u = $("#unv"); if (u) u.onclick = () => { unVisit(s.key); closeSheet(); render(); };
    }

    render(!st.origin);
    if (st.origin) map.setView(st.origin, 15);
  }

  /* ── 업종 카드 */
  async function cardsView() {
    chrome("업종 카드", "업종별 필요한 보험과 첫 방문 화법", null, "cards");
    view.innerHTML = `
      <p class="lead">사업장 보험으로 <b>문을 열고</b>, 사장님·직원 <b>인보험</b>으로 연결하는 흐름이에요. 플래너 내부 학습용입니다.</p>
      <div class="cgrid">${CARDS.map(c => `
        <a class="ccard" href="#/card/${c.id}" style="--c:${c.color}">
          <b>${c.name}</b><small>${esc(c.hook)}</small>
        </a>`).join("")}</div>`;
  }

  function cardDetail(id) {
    const c = CARD[id];
    if (!c) return (location.hash = "#/cards");
    const last = store.get("lastRegion", null);
    const back = last && META && region(last) && META.regions.find(r => r.code === last).cards[id] ? `#/r/${last}/${id}` : "#/cards";
    chrome(c.name, "첫 방문 카드 · 내부 학습용", back, "cards");
    const ul = a => `<ul>${a.map(x => `<li>${esc(x)}</li>`).join("")}</ul>`;
    view.innerHTML = `
      <div class="detail" style="--c:${c.color}">
        <div class="when">
          <div><small>방문 시간</small><b>${esc(c.time)}</b></div>
          <div><small>누구를 만나나</small><b>${esc(c.who)}</b></div>
        </div>
        <section><h3><span>1</span>문 여는 화제 · 사업장 점검</h3>${ul(c.biz)}</section>
        <section class="hl"><h3><span>2</span>인보험 연결 포인트</h3>${ul(c.person)}</section>
        <section><h3><span>3</span>첫 방문 화법</h3>
          <ol class="talk">${c.open.map(x => `<li>${esc(x)}</li>`).join("")}</ol></section>
        <section><h3><span>4</span>자주 나오는 거절과 대응</h3>
          ${c.objections.map(([q, a]) => `<div class="obj"><p class="q">“${esc(q)}”</p><p class="a">${esc(a)}</p></div>`).join("")}</section>
        ${c.tip ? `<section><h3><span>+</span>팁</h3><p>${esc(c.tip)}</p></section>` : ""}
        <section class="common"><h3>모든 업종 공통</h3>${ul(COMMON_TIPS)}</section>
        <p class="foot">의무보험 대상 여부는 면적·층수·업태에 따라 다르니 단정하지 말고 증권으로 확인하세요. 이 카드는 고객 배포용이 아닙니다.</p>
      </div>`;
  }

  /* ── 방문 기록 */
  async function logView() {
    await meta();
    chrome("방문 기록", "이 휴대폰에만 저장돼요", null, "log");
    const v = visits();
    const arr = Object.entries(v).map(([k, x]) => ({ k, ...x, last: x.dates[x.dates.length - 1] }))
      .sort((a, b) => b.last.localeCompare(a.last));
    const week = arr.filter(x => daysSince(x.last) < 7).length;
    const re = arr.filter(x => x.dates.length < 2 && daysSince(x.last) >= 7);
    const item = x => {
      const c = CARD[x.cid] || { color: "#999", name: "" };
      const ds = daysSince(x.last);
      return `<div class="item" data-k="${esc(x.k)}">
        <div class="it-main"><b>${esc(x.name)}</b>
          <small>${c.name} · ${esc(x.kind || "")} · 방문 ${x.dates.length}회</small>
          ${x.memo ? `<small class="addr">${esc(x.memo)}</small>` : ""}</div>
        <div class="it-side"><em>${ds === 0 ? "오늘" : ds + "일 전"}</em>
          <a class="mini" href="${naverTo(x)}" target="_blank" rel="noopener">네이버지도</a></div>
      </div>`;
    };
    view.innerHTML = `
      <div class="stats">
        <div><b>${week}</b><small>최근 7일 방문</small></div>
        <div><b>${arr.length}</b><small>누적 방문 매장</small></div>
        <div class="accent"><b>${re.length}</b><small>재방문할 곳</small></div>
      </div>
      ${re.length ? `<h4 class="sec">재방문할 때가 됐어요 <small>첫 방문 후 7일 지남</small></h4><div class="list">${re.map(item).join("")}</div>` : ""}
      <h4 class="sec">전체 기록</h4>
      <div class="list">${arr.length ? arr.map(item).join("") : `<div class="empty">아직 방문 기록이 없어요.<br>지도에서 가게를 누르고 <b>방문했어요</b>를 눌러 보세요.</div>`}</div>
      ${arr.length ? `<button class="btn ghost more" id="clear">기록 전체 지우기</button>` : ""}`;
    const cl = $("#clear");
    if (cl) cl.onclick = () => { if (confirm("방문 기록을 모두 지울까요?")) { store.set("visits", {}); logView(); } };
  }

  /* ── 바텀시트 */
  function showSheet(html) {
    const s = $("#sheet");
    s.innerHTML = `<div class="sh-bg"></div><div class="sh-body"><div class="grab"></div>${html}</div>`;
    s.hidden = false; requestAnimationFrame(() => s.classList.add("open"));
    $(".sh-bg", s).onclick = closeSheet;
  }
  function closeSheet() { const s = $("#sheet"); s.classList.remove("open"); s.hidden = true; s.innerHTML = ""; }

  /* ── 라우터 */
  async function route() {
    const h = location.hash.replace(/^#\/?/, "").split("/");
    try {
      if (map && !(h[0] === "r" && h[2])) { map.remove(); map = null; }
      if (h[0] === "r" && h[2]) await explore(h[1], h[2]);
      else if (h[0] === "r" && h[1]) await regionView(h[1]);
      else if (h[0] === "cards") await cardsView();
      else if (h[0] === "card") { await meta(); cardDetail(h[1]); }
      else if (h[0] === "log") await logView();
      else await home();
    } catch (e) {
      console.error(e);
      view.innerHTML = `<div class="empty">데이터를 불러오지 못했어요. 잠시 후 다시 열어 주세요.</div>`;
    }
  }
  window.addEventListener("hashchange", route);
  route();
})();
